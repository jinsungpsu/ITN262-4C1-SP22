package com.example.todolist;

public class TaskQueueTester {
    public static void main(String[] args) {
        Task t1 = new Task("sleep", "go to sleep", false, 1);
        Task t2 = new Task("study", "hit the books", false, 2);
        Task t3 = new Task("Eat", "put some food in your stomach", false, 1);


        TaskQueue mytasklist = new ArrayTaskQueue();

        mytasklist.addTask(t1);
        mytasklist.addTask(t2);
        mytasklist.addTask(t3);

        System.out.println(mytasklist);

        System.out.println("Removing oldest task: " + mytasklist.removeOldestTask());

        System.out.println(mytasklist);
    }
}
