package com.example.todolist;

public class Task {
    private String name, description;
    private boolean isCompleted;
    private int priority;

    public Task(String name) {
        this.name = name;

        // default values
        description = "no description entered.";
        isCompleted = false;
        priority = 5;
    }

    public Task(String name, String description, boolean isCompleted, int priority) {
        this.name = name;
        this.description = description;
        this.isCompleted = isCompleted;
        this.priority = priority;
    }

    @Override
    public String toString() {
        return "Task{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", isCompleted=" + isCompleted +
                ", priority=" + priority +
                '}';
    }

    // @Override
    public boolean equals(Task another) {
        if (this.name.equals(another.name))
            return true;
        else
            return false;
    }
}
