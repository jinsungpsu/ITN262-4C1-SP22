package com.example.todolist;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class ToDoMainScreenController {

    private ArrayTaskQueue tasklist = new ArrayTaskQueue();

    @FXML
    private Button addTaskBtn;

    @FXML
    private TextField addTaskTextField;

    @FXML
    private Button removeTaskBtn;

    @FXML
    private ListView<Task> toDoListView;

    @FXML
    void addTaskHandler(ActionEvent event) {
        String taskName = addTaskTextField.getText();
        Task task = new Task(taskName);

        tasklist.addTask(task);

        refreshTaskListView();

    }

    private void refreshTaskListView() {
        // take everything in my ArrayTaskQueue object
        // and put it into the ListView object

        toDoListView.getItems().clear();

        Task[] allTaskArray = tasklist.getTasklist();

        for (int i = 0; i < tasklist.getCount(); i++) {
            toDoListView.getItems().add(allTaskArray[i]);
        }

    }

    @FXML
    void removeTaskHandler(ActionEvent event) {
        // remove oldest task.. which means to dequeue
    }

    @FXML
    void removeSelectedTaskHandler(ActionEvent event) {
        Task selectedTask = toDoListView.getSelectionModel().getSelectedItem();
        System.out.println(selectedTask);

        tasklist.removeTask(selectedTask);

        refreshTaskListView();
    }

}
