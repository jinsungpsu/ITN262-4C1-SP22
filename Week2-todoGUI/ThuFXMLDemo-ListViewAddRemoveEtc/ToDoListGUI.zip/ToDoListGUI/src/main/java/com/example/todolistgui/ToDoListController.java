package com.example.todolistgui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class ToDoListController {
    private ObservableList<String> todoObservableList = FXCollections.observableArrayList("Task1", "Task2", "Task3");

    @FXML
    private ListView<String> taskList;

    @FXML
    private Button addTaskBtn;

    @FXML
    private Button clearWholeListBtn;

    @FXML
    private TextField newTaskTextField;

    @FXML
    private Button removeTaskBtn;

    @FXML
    public void initialize() {
        // this code runs when the controller is loaded
        taskList.setItems(todoObservableList);
    }

    @FXML
    void addTaskBtnClicked(ActionEvent event) {
        addTask();
    }

    private void addTask() {
        String newTask = newTaskTextField.getText();

        if (!newTask.equals("")) {
            todoObservableList.add(newTask);
        }
    }

    @FXML
    void removeTask(ActionEvent event) {

        MultipleSelectionModel<String> selectedModel = taskList.getSelectionModel();
        String selectedTask = selectedModel.getSelectedItem();

        // same exact thing as
        // String selectedThing = taskList.getSelectionModel().getSelectedItem();

        System.out.println(selectedTask);

        todoObservableList.remove(selectedTask);

    }

}
