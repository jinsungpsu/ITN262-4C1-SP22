package com.example.todolist;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ToDoMainScreenController {


    @FXML
    private Button addTaskBtn;

    @FXML
    private TextField addTaskTextField;

    @FXML
    private Button removeTaskBtn;

    @FXML
    private ListView<Task> toDoListView;

    @FXML
    void addTaskHandler(ActionEvent event) {
        String taskName = addTaskTextField.getText();
        Task task = new Task(taskName);

        ToDoDB.tasklist.addTask(task);

        refreshTaskListView();

    }

    private void refreshTaskListView() {
        // take everything in my ArrayTaskQueue object
        // and put it into the ListView object

        toDoListView.getItems().clear();

        Task[] allTaskArray = ToDoDB.tasklist.getTasklist();

        for (int i = 0; i < ToDoDB.tasklist.getCount(); i++) {
            toDoListView.getItems().add(allTaskArray[i]);
        }

    }

    @FXML
    void removeTaskHandler(ActionEvent event) {
        ToDoDB.completedTasks.addTask(ToDoDB.tasklist.removeOldestTask());

        refreshTaskListView();

    }

    @FXML
    void removeSelectedTaskHandler(ActionEvent event) {
        Task selectedTask = toDoListView.getSelectionModel().getSelectedItem();
        System.out.println(selectedTask);

        ToDoDB.tasklist.removeTask(selectedTask);

        refreshTaskListView();
    }

    @FXML
    void viewCompletedTasksBtn(ActionEvent event) {

        Stage newStage = new Stage();

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("completedtasks-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            newStage.setTitle("To Do App");
            newStage.setScene(scene);
            newStage.show();
        } catch (IOException e) {
            System.out.println("Trouble with opening FXML.");
            System.out.println(e);
        }
    }

}
