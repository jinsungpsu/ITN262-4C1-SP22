package com.example.todolist;

public interface TaskQueue {
    public void addTask(Task task);

    public Task removeTask(Task task);

    public Task removeOldestTask();

    public void clearAllTasks();
}
