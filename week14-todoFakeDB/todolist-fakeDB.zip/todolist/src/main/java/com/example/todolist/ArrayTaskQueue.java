package com.example.todolist;

public class ArrayTaskQueue implements TaskQueue {
    private Task[] tasklist;
    private final int DEFAULT_SIZE = 20;
    private int front=0, back=0, count;

    public ArrayTaskQueue() {
        tasklist = new Task[DEFAULT_SIZE];
    }

    public ArrayTaskQueue(int size) {
        tasklist = new Task[size];
    }

    @Override
    public void addTask(Task task) {
        // enqueueing - add it to the "back" of the queue

        // check capacity
        if (count < tasklist.length) {
            tasklist[back % tasklist.length] = task;
            back++;
            count++;
        }

    }

    @Override
    public Task removeTask(Task task) {
        boolean foundTask = false;

        // logic for removing task is different..

        // do a search
        for (int i = 0; i < count; i++) {
            if (task.equals(tasklist[(i+front)%tasklist.length])) {
                // found!
                System.out.println("Found the task!");
                foundTask = true;

            }
        }
        // not found
        if (!foundTask) {
            System.out.println("Did not find the task!");
        }
        // get rid of the space that it left in the middle

        // update back, front, and count accordingly
        return null;
    }

    @Override
    public Task removeOldestTask() {
        // dequeing - remove what's in the "front" of the queue

        if (count == 0) {
            return null;
        } else {
            Task task = tasklist[front];
            tasklist[front] = null;
            front++;
            count--;

            return task;
        }
    }

    @Override
    public void clearAllTasks() {

    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < count; i++) {
            output.append(tasklist[(i+front)%tasklist.length] + "\n");
        }
        return output.toString();
    }

    public Task[] getTasklist() {

        Task[] actualTaskList = new Task[count];

        for (int i = 0; i < count; i++) {
            actualTaskList[i] = tasklist[(i+front)%tasklist.length];
        }


        return actualTaskList;
    }

    public int getCount() {
        return count;
    }
}
