package com.example.todolist;

public class ToDoDB {

    // fake database
    static public ArrayTaskQueue tasklist = new ArrayTaskQueue();
    static public ArrayTaskQueue completedTasks = new ArrayTaskQueue();

}
